import pandas as pd
from datetime import datetime, timedelta

# Load your CSV file (without headers if your CSV has none)
df = pd.read_csv('output1.csv', header=None)

# Assign proper column names matching plotmq135.py
df.columns = ['Index', 'ADCValue', 'VoltageOut', 'VoltageAO', 'Resistance_kOhm']

# Starting timestamp as datetime
start_time_str = "16:05:11.226"
start_time = datetime.strptime(start_time_str, "%H:%M:%S.%f")

# Generate timestamps with 1000 ms intervals and format as HH:MM:SS.sss string
df['Timestamp'] = [(start_time + timedelta(milliseconds=1000 * i)).strftime("%H:%M:%S.%f")[:-3] for i in range(len(df))]

# Move Timestamp to first column
columns = ['Timestamp'] + [col for col in df.columns if col != 'Timestamp']
df = df[columns]

# Save to new CSV
df.to_csv('output_with_timestamps1.csv', index=False)

print("Timestamps added (time only) and saved to output_with_timestamps2.csv")
