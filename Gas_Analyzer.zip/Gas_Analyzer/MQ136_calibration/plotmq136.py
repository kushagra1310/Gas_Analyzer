import pandas as pd
import matplotlib.pyplot as plt

# === Load CSV ===
df = pd.read_csv("output_with_timestamps1.csv")

# Show column names
print("Columns found:", df.columns.tolist())

# === Clean column names ===
df.columns = df.columns.str.strip().str.lower()

# === Convert Timestamp column to numeric (force errors to NaN) ===
df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce")

# Drop rows where timestamp couldn't be converted
df = df.dropna(subset=["timestamp"])

# === Convert timestamp to seconds ===
df["time_s"] = df["timestamp"] / 1000.0

# === Plot Resistance vs Time ===
plt.figure(figsize=(10, 5))
plt.plot(df["time_s"], df["resistance_kohm"], label="Sensor Resistance (kΩ)", linewidth=2)
plt.title("MQ Sensor Resistance Over Time")
plt.xlabel("Time (seconds)")
plt.ylabel("Resistance (kΩ)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# === Plot Voltage vs Time ===
plt.figure(figsize=(10, 5))
plt.plot(df["time_s"], df["voltageout"], label="Output Voltage (V)", color="orange", linewidth=2)
plt.title("MQ Sensor Output Voltage Over Time")
plt.xlabel("Time (seconds)")
plt.ylabel("Voltage (V)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
